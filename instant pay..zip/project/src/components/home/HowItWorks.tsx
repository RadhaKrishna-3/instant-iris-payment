import React from 'react';
import { motion } from 'framer-motion';
import { 
  Eye, 
  Shield, 
  Banknote, 
  CheckCircle, 
  ArrowRight 
} from 'lucide-react';
import Button from '../common/Button';

const steps = [
  {
    icon: <Eye />,
    title: 'Iris Scan',
    description: 'Look into the scanner for a quick, secure biometric capture of your unique iris pattern.'
  },
  {
    icon: <Shield />,
    title: 'Verification',
    description: 'Multiple AI agents work in parallel to authenticate your identity and verify the transaction.'
  },
  {
    icon: <Banknote />,
    title: 'Processing',
    description: 'The system processes the payment through secure banking channels within milliseconds.'
  },
  {
    icon: <CheckCircle />,
    title: 'Confirmation',
    description: 'Receive instant confirmation of your successful, secure transaction.'
  }
];

const HowItWorks: React.FC = () => {
  return (
    <section className="py-24 bg-gradient-to-br from-purple-50 to-teal-50">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            How IRISPay <span className="gradient-text">Works</span>
          </h2>
          <p className="text-slate-600 text-lg">
            Our secure, frictionless payment process takes just seconds to complete,
            with multiple AI agents working behind the scenes to ensure security and speed.
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Connection line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-purple-100 -translate-x-1/2 z-0"></div>
            
            {/* Steps */}
            {steps.map((step, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
                className="relative z-10 mb-12 last:mb-0"
              >
                <div className={`flex items-start gap-6 ${index % 2 === 1 ? 'flex-row-reverse' : ''}`}>
                  <div className="flex-shrink-0 w-16 h-16 bg-white rounded-full shadow-md flex items-center justify-center border-4 border-purple-100">
                    <div className="text-purple-700">
                      {step.icon}
                    </div>
                  </div>
                  
                  <div className={`bg-white rounded-lg shadow-md p-6 max-w-sm ${index % 2 === 1 ? 'text-right' : ''}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center text-purple-700 text-sm font-bold ${index % 2 === 1 ? 'order-last' : ''}`}>
                        {index + 1}
                      </div>
                      <h3 className="text-xl font-semibold">{step.title}</h3>
                    </div>
                    <p className="text-slate-600">{step.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Button 
              to="/how-it-works"
              variant="primary"
              icon={<ArrowRight size={20} />}
              iconPosition="right"
            >
              See Detailed Process
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;