import React from 'react';
import { motion } from 'framer-motion';
import Button from '../common/Button';
import { ArrowRight } from 'lucide-react';

const CTA: React.FC = () => {
  return (
    <section className="py-24 bg-gradient-to-br from-purple-900 to-indigo-900 text-white">
      <div className="container-custom">
        <motion.div 
          className="max-w-4xl mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Experience the Future of Payments?
          </h2>
          <p className="text-lg text-purple-100 mb-10 max-w-2xl mx-auto">
            Join the revolution in payment technology. Experience the security, speed, 
            and convenience of IRISPay's biometric payment system.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              to="/demo" 
              variant="secondary"
              size="lg"
              icon={<ArrowRight size={20} />}
              iconPosition="right"
            >
              Try the Demo
            </Button>
            <Button 
              href="#" 
              className="bg-white hover:bg-gray-100 text-purple-900"
              size="lg"
            >
              Contact Sales
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTA;