import React from 'react';
import { motion } from 'framer-motion';
import Card from '../common/Card';
import { UserCircle, FileText, ShieldAlert, Ban as Bank, ClipboardList } from 'lucide-react';

const agents = [
  {
    icon: <UserCircle size={32} />,
    title: 'User Identification Agent',
    description: 'Captures and analyzes iris patterns using deep learning algorithms for secure authentication.',
    color: 'bg-purple-100 text-purple-700'
  },
  {
    icon: <FileText size={32} />,
    title: 'Transaction Request Agent',
    description: 'Prepares and validates payment requests to ensure all required information is correct.',
    color: 'bg-teal-100 text-teal-700'
  },
  {
    icon: <ShieldAlert size={32} />,
    title: 'Security & Risk Check Agent',
    description: 'Performs real-time fraud detection using AI models to protect both buyer and seller.',
    color: 'bg-red-100 text-red-700'
  },
  {
    icon: <Bank size={32} />,
    title: 'Bank API Interface Agent',
    description: 'Securely connects with banking systems to process transactions through appropriate channels.',
    color: 'bg-blue-100 text-blue-700'
  },
  {
    icon: <ClipboardList size={32} />,
    title: 'Audit & Logging Agent',
    description: 'Maintains detailed, secure transaction records for compliance and troubleshooting.',
    color: 'bg-amber-100 text-amber-700'
  }
];

const Agents: React.FC = () => {
  return (
    <section className="py-24 bg-slate-50">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            <span className="gradient-text">Multi-Agent</span> System
          </h2>
          <p className="text-slate-600 text-lg">
            IRISPay's intelligent agents work together to ensure every transaction 
            is secure, fast, and reliable. Each agent has a specialized role in the payment process.
          </p>
        </div>
        
        <div className="relative">
          {/* Center hexagon with connections */}
          <div className="hidden lg:block absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32">
            <div className="absolute inset-0 bg-white rounded-full shadow-lg flex items-center justify-center">
              <div className="text-3xl font-bold gradient-text">IRIS</div>
            </div>
            
            {/* Connection lines */}
            {[0, 1, 2, 3, 4].map((index) => {
              const angle = (index * (2 * Math.PI / 5)) - Math.PI / 2;
              const x1 = 16 * Math.cos(angle);
              const y1 = 16 * Math.sin(angle);
              const x2 = 160 * Math.cos(angle);
              const y2 = 160 * Math.sin(angle);
              
              return (
                <svg
                  key={index}
                  className="absolute top-1/2 left-1/2 w-full h-full -translate-x-1/2 -translate-y-1/2"
                  style={{ 
                    width: '400px', 
                    height: '400px' 
                  }}
                >
                  <line
                    x1={200 + x1}
                    y1={200 + y1}
                    x2={200 + x2}
                    y2={200 + y2}
                    stroke="#d8b4fe"
                    strokeWidth="2"
                    strokeDasharray="4 4"
                  />
                </svg>
              );
            })}
          </div>
          
          {/* Agent cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative z-10">
            {agents.map((agent, index) => {
              // Position the middle card in center on larger screens
              const isMiddleCard = index === 2;
              const gridColClass = isMiddleCard ? 'lg:col-start-2' : '';
              
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true, margin: "-100px" }}
                  className={gridColClass}
                >
                  <Card hover className="h-full">
                    <div className="flex flex-col h-full">
                      <div className={`w-16 h-16 rounded-lg flex items-center justify-center mb-5 ${agent.color}`}>
                        {agent.icon}
                      </div>
                      <h3 className="text-xl font-semibold mb-3">{agent.title}</h3>
                      <p className="text-slate-600 flex-grow">{agent.description}</p>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Agents;