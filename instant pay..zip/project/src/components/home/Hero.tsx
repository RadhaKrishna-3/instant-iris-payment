import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import Button from '../common/Button';
import { ArrowRight, Eye } from 'lucide-react';

const Hero: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(canvas.width, canvas.height) * 0.35;
    
    const drawIris = () => {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Outer iris circle
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.fillStyle = '#4c1d95';
      ctx.fill();
      
      // Inner iris patterns
      for (let i = 0; i < 360; i += 15) {
        const angle = (i * Math.PI) / 180;
        const innerRadius = radius * 0.2;
        const outerRadius = radius * 0.9;
        
        ctx.beginPath();
        ctx.moveTo(
          centerX + innerRadius * Math.cos(angle),
          centerY + innerRadius * Math.sin(angle)
        );
        ctx.lineTo(
          centerX + outerRadius * Math.cos(angle),
          centerY + outerRadius * Math.sin(angle)
        );
        ctx.strokeStyle = '#5b21b6';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      
      // Pupil
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * 0.3, 0, Math.PI * 2);
      ctx.fillStyle = '#18181b';
      ctx.fill();
      
      // Highlight
      ctx.beginPath();
      ctx.arc(centerX - radius * 0.15, centerY - radius * 0.15, radius * 0.08, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.fill();
      
      // Scanning effect
      const timestamp = Date.now() / 1000;
      const scanY = centerY + Math.sin(timestamp * 2) * radius * 0.5;
      
      ctx.beginPath();
      ctx.moveTo(centerX - radius, scanY);
      ctx.lineTo(centerX + radius, scanY);
      ctx.strokeStyle = 'rgba(20, 184, 166, 0.6)';
      ctx.lineWidth = 3;
      ctx.stroke();
      
      requestAnimationFrame(drawIris);
    };
    
    const animate = requestAnimationFrame(drawIris);
    
    const handleResize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      cancelAnimationFrame(animate);
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-purple-50 to-white pt-16 pb-24 md:pt-20 md:pb-32">
      {/* Background decorative elements */}
      <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
      <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-96 h-96 bg-teal-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
      
      <div className="container-custom relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          <div className="lg:w-1/2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 bg-purple-100 text-purple-800 px-4 py-2 rounded-full text-sm font-medium mb-6">
                <Eye size={16} />
                <span>Revolutionary Payment Solution</span>
              </div>
              
              <h1 className="font-bold mb-6">
                <span className="block text-slate-900">Secure Payments</span>
                <span className="gradient-text">Using Your Eyes</span>
              </h1>
              
              <p className="text-slate-600 text-lg md:text-xl leading-relaxed mb-8 max-w-2xl">
                IRISPay uses advanced iris recognition technology and multi-agent AI to enable secure, 
                instantaneous payments—no cards, phones, or passwords needed.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Button 
                  to="/demo" 
                  variant="primary" 
                  size="lg"
                  icon={<ArrowRight size={20} />}
                  iconPosition="right"
                >
                  Try the Demo
                </Button>
                <Button 
                  to="/how-it-works" 
                  variant="outline" 
                  size="lg"
                >
                  How It Works
                </Button>
              </div>
            </motion.div>
          </div>
          
          <div className="lg:w-1/2">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative aspect-square max-w-md mx-auto"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-teal-500/20 rounded-full"></div>
              <canvas 
                ref={canvasRef} 
                className="w-full h-full rounded-full shadow-xl"
              ></canvas>
            </motion.div>
          </div>
        </div>
        
        {/* Brands/Partners section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-20 pt-10 border-t border-slate-200"
        >
          <p className="text-center text-slate-500 mb-8">Trusted by leading companies and institutions</p>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12 opacity-70">
            {['HSBC', 'Barclays', 'Standard Chartered', 'PayPal', 'Visa'].map((brand, index) => (
              <div key={index} className="text-slate-400 font-bold text-xl">
                {brand}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Hero;