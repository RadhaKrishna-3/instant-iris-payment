import React from 'react';
import { motion } from 'framer-motion';
import Card from '../common/Card';
import { 
  Eye, 
  ShieldCheck, 
  Zap, 
  Globe, 
  Clock, 
  UsersRound 
} from 'lucide-react';

const features = [
  {
    icon: <Eye />,
    title: 'Iris Recognition',
    description: 'Secure biometric authentication using the uniqueness of the human iris pattern.'
  },
  {
    icon: <ShieldCheck />,
    title: 'Enhanced Security',
    description: 'Multi-layered security with fraud detection and instant verification.'
  },
  {
    icon: <Zap />,
    title: 'Instant Payments',
    description: 'Complete transactions in milliseconds with our advanced processing system.'
  },
  {
    icon: <Globe />,
    title: 'Global Compatibility',
    description: 'Works across borders with multiple currencies and payment systems.'
  },
  {
    icon: <Clock />,
    title: '24/7 Availability',
    description: 'Always-on system with no downtimes or maintenance windows.'
  },
  {
    icon: <UsersRound />,
    title: 'Multi-Agent System',
    description: 'AI agents working together to ensure every transaction is smooth and secure.'
  }
];

const Features: React.FC = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };
  
  return (
    <section className="py-24 bg-white">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Revolutionizing Payments with <span className="gradient-text">Advanced Technology</span>
          </h2>
          <p className="text-slate-600 text-lg">
            IRISPay combines cutting-edge biometric recognition with intelligent multi-agent systems 
            to create a seamless, secure payment experience like never before.
          </p>
        </div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
        >
          {features.map((feature, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card hover className="h-full">
                <div className="flex flex-col h-full">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center text-purple-700 mb-5">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                  <p className="text-slate-600 flex-grow">{feature.description}</p>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Features;