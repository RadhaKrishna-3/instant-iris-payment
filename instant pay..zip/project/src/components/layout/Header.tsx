import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { Menu, X, Eye } from 'lucide-react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  const navLinkClasses = ({ isActive }: { isActive: boolean }) => 
    `relative px-3 py-2 font-medium text-sm transition-colors ${
      isActive 
        ? 'text-purple-700' 
        : 'text-slate-700 hover:text-purple-700'
    }`;
  
  return (
    <header 
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-sm shadow-sm' 
          : 'bg-transparent'
      }`}
    >
      <div className="container-custom flex items-center justify-between h-16 md:h-20">
        <div className="flex items-center">
          <NavLink to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-teal-500 rounded-lg flex items-center justify-center">
              <Eye className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-700 to-teal-500">IRISPay</span>
          </NavLink>
        </div>
        
        {/* Desktop navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          <NavLink to="/" className={navLinkClasses} end>
            Home
          </NavLink>
          <NavLink to="/how-it-works" className={navLinkClasses}>
            How It Works
          </NavLink>
          <NavLink to="/technology" className={navLinkClasses}>
            Technology
          </NavLink>
          <NavLink to="/demo" className={navLinkClasses}>
            Demo
          </NavLink>
          <div className="ml-4">
            <NavLink to="/demo" className="btn btn-primary">
              Try Demo
            </NavLink>
          </div>
        </nav>
        
        {/* Mobile menu button */}
        <button 
          className="md:hidden p-2 text-slate-700"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 animate-fade-in">
          <nav className="container-custom py-4 flex flex-col space-y-3">
            <NavLink 
              to="/" 
              className={navLinkClasses} 
              end
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </NavLink>
            <NavLink 
              to="/how-it-works" 
              className={navLinkClasses}
              onClick={() => setIsMenuOpen(false)}
            >
              How It Works
            </NavLink>
            <NavLink 
              to="/technology" 
              className={navLinkClasses}
              onClick={() => setIsMenuOpen(false)}
            >
              Technology
            </NavLink>
            <NavLink 
              to="/demo" 
              className={navLinkClasses}
              onClick={() => setIsMenuOpen(false)}
            >
              Demo
            </NavLink>
            <div className="pt-2">
              <NavLink 
                to="/demo" 
                className="btn btn-primary w-full"
                onClick={() => setIsMenuOpen(false)}
              >
                Try Demo
              </NavLink>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;