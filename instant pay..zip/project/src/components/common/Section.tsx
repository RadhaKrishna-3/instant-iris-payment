import React from 'react';

type SectionProps = {
  children: React.ReactNode;
  className?: string;
  id?: string;
  fullWidth?: boolean;
  backgroundColor?: string;
};

const Section: React.FC<SectionProps> = ({
  children,
  className = '',
  id,
  fullWidth = false,
  backgroundColor = '',
}) => {
  return (
    <section 
      id={id} 
      className={`py-16 md:py-24 ${backgroundColor} ${className}`}
    >
      <div className={fullWidth ? 'w-full' : 'container-custom'}>
        {children}
      </div>
    </section>
  );
};

export default Section;