import React from 'react';

type CardProps = {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
};

const Card: React.FC<CardProps> = ({ 
  children, 
  className = '', 
  hover = false 
}) => {
  const hoverClasses = hover ? 'hover:shadow-lg hover:-translate-y-1' : '';
  
  return (
    <div className={`bg-white rounded-xl shadow-md p-6 transition-all duration-200 ${hoverClasses} ${className}`}>
      {children}
    </div>
  );
};

export default Card;