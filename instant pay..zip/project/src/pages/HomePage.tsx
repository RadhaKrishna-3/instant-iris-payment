import React, { useEffect } from 'react';
import Hero from '../components/home/Hero';
import Features from '../components/home/Features';
import HowItWorks from '../components/home/HowItWorks';
import Agents from '../components/home/Agents';
import CTA from '../components/home/CTA';

const HomePage: React.FC = () => {
  useEffect(() => {
    document.title = 'IRISPay - Biometric Payment Solution';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);
  
  return (
    <>
      <Hero />
      <Features />
      <HowItWorks />
      <Agents />
      <CTA />
    </>
  );
};

export default HomePage;