import React, { useEffect } from 'react';
import Section from '../components/common/Section';
import Card from '../components/common/Card';
import { motion } from 'framer-motion';
import { Eye, Shield, Banknote, CheckCircle, UserCircle, FileText, ShieldAlert, Ban as Bank, ClipboardList, ArrowRight, ArrowDown } from 'lucide-react';

const HowItWorksPage: React.FC = () => {
  useEffect(() => {
    document.title = 'How It Works - IRISPay';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);
  
  return (
    <div>
      {/* Hero section */}
      <Section className="bg-gradient-to-br from-purple-50 to-teal-50 pt-16 pb-20">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            How <span className="gradient-text">IRISPay</span> Works
          </h1>
          <p className="text-slate-600 text-lg md:text-xl">
            A comprehensive look at our revolutionary biometric payment system,
            from iris scanning to transaction completion.
          </p>
        </div>
      </Section>
      
      {/* Process Overview */}
      <Section>
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-12 text-center">Payment Process Overview</h2>
          
          <div className="relative">
            {/* Connection line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-purple-100 -translate-x-1/2 z-0"></div>
            
            {/* Process steps */}
            {[
              {
                icon: <Eye size={24} />,
                title: "1. Iris Scanning",
                description: "The user looks into the IRISPay scanner, which captures a detailed image of their iris pattern. This unique biometric identifier is as distinctive as a fingerprint but even more secure and impossible to forge."
              },
              {
                icon: <Shield size={24} />,
                title: "2. Biometric Authentication",
                description: "The IrisAuth Agent processes the scan using deep learning algorithms to match it against the stored encrypted biometric template. This happens in milliseconds with extremely high accuracy."
              },
              {
                icon: <Banknote size={24} />,
                title: "3. Transaction Processing",
                description: "Once identity is confirmed, the Transaction Agent prepares the payment details while the Security Agent performs real-time risk assessment. The Bank API Agent then securely communicates with financial systems."
              },
              {
                icon: <CheckCircle size={24} />,
                title: "4. Confirmation & Receipt",
                description: "The transaction is completed, and the Audit Agent logs all details securely. The user receives instant confirmation, and a digital receipt is generated and stored in their account."
              }
            ].map((step, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
                className="relative z-10 mb-16 last:mb-0"
              >
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0 w-16 h-16 bg-white rounded-full shadow-md flex items-center justify-center border-4 border-purple-100">
                    <div className="text-purple-700">
                      {step.icon}
                    </div>
                  </div>
                  
                  <Card className="flex-grow">
                    <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                    <p className="text-slate-600">{step.description}</p>
                  </Card>
                </div>
                
                {index < 3 && (
                  <div className="absolute left-1/2 -translate-x-1/2 mt-4 text-purple-400">
                    <ArrowDown size={24} />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </Section>
      
      {/* Multi-Agent System */}
      <Section backgroundColor="bg-slate-50">
        <h2 className="text-3xl font-bold mb-12 text-center">The Multi-Agent System</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            {
              icon: <UserCircle size={32} />,
              title: 'User Identification Agent',
              description: 'Captures and processes iris scans using deep learning models trained on millions of iris patterns. The agent handles different lighting conditions and ensures the scan is of sufficient quality.',
              color: 'bg-purple-100 text-purple-700'
            },
            {
              icon: <FileText size={32} />,
              title: 'Transaction Request Agent',
              description: 'Manages the transaction details, including amount, recipient information, and purpose. This agent ensures all required information is collected and validated before processing.',
              color: 'bg-teal-100 text-teal-700'
            },
            {
              icon: <ShieldAlert size={32} />,
              title: 'Security & Risk Check Agent',
              description: 'Analyzes each transaction for potential fraud using behavioral patterns, transaction history, and anomaly detection. It employs sophisticated AI models to identify suspicious activities in real-time.',
              color: 'bg-red-100 text-red-700'
            },
            {
              icon: <Bank size={32} />,
              title: 'Bank API Interface Agent',
              description: 'Securely communicates with banking systems using encrypted channels. This agent handles the actual money transfer, working with multiple payment networks and financial institutions.',
              color: 'bg-blue-100 text-blue-700'
            },
            {
              icon: <ClipboardList size={32} />,
              title: 'Audit & Logging Agent',
              description: 'Maintains a secure, immutable record of all transactions for compliance and troubleshooting. Every action in the system is logged with timestamps and appropriate metadata.',
              color: 'bg-amber-100 text-amber-700'
            }
          ].map((agent, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true, margin: "-100px" }}
            >
              <Card hover className="h-full">
                <div className="flex flex-col h-full">
                  <div className={`w-16 h-16 rounded-lg flex items-center justify-center mb-5 ${agent.color}`}>
                    {agent.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{agent.title}</h3>
                  <p className="text-slate-600 flex-grow">{agent.description}</p>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-semibold mb-6">How Agents Communicate</h3>
          <p className="text-slate-600 max-w-3xl mx-auto mb-10">
            IRISPay's agents communicate through a secure, encrypted message bus system. 
            Each agent operates independently but shares information through standardized protocols. 
            This architecture ensures that the system remains operational even if one agent experiences issues, 
            providing robust fault tolerance and high availability.
          </p>
          
          <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-md p-8 overflow-hidden">
            <div className="relative">
              <svg className="w-full h-auto" viewBox="0 0 800 400" xmlns="http://www.w3.org/2000/svg">
                {/* Central hub */}
                <circle cx="400" cy="200" r="60" fill="#f3e8ff" stroke="#a855f7" strokeWidth="3" />
                <text x="400" y="205" textAnchor="middle" fontSize="16" fontWeight="bold" fill="#a855f7">Message Bus</text>
                
                {/* Agents */}
                <g>
                  <circle cx="200" cy="100" r="50" fill="#f5f3ff" stroke="#8b5cf6" strokeWidth="2" />
                  <text x="200" y="105" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#8b5cf6">User ID Agent</text>
                  <path d="M245 130 L 350 170" stroke="#c4b5fd" strokeWidth="2" strokeDasharray="5,5" />
                  <polygon points="354,172 345,175 347,166" fill="#c4b5fd" />
                </g>
                
                <g>
                  <circle cx="200" cy="300" r="50" fill="#ecfdf5" stroke="#14b8a6" strokeWidth="2" />
                  <text x="200" y="305" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#14b8a6">Transaction Agent</text>
                  <path d="M245 270 L 350 220" stroke="#99f6e4" strokeWidth="2" strokeDasharray="5,5" />
                  <polygon points="354,218 345,215 347,224" fill="#99f6e4" />
                </g>
                
                <g>
                  <circle cx="600" cy="100" r="50" fill="#fef2f2" stroke="#ef4444" strokeWidth="2" />
                  <text x="600" y="105" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#ef4444">Security Agent</text>
                  <path d="M555 130 L 450 170" stroke="#fca5a5" strokeWidth="2" strokeDasharray="5,5" />
                  <polygon points="446,172 455,175 453,166" fill="#fca5a5" />
                </g>
                
                <g>
                  <circle cx="600" cy="300" r="50" fill="#eff6ff" stroke="#3b82f6" strokeWidth="2" />
                  <text x="600" y="305" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#3b82f6">Bank API Agent</text>
                  <path d="M555 270 L 450 220" stroke="#93c5fd" strokeWidth="2" strokeDasharray="5,5" />
                  <polygon points="446,218 455,215 453,224" fill="#93c5fd" />
                </g>
                
                <g>
                  <circle cx="400" cy="350" r="50" fill="#fffbeb" stroke="#f59e0b" strokeWidth="2" />
                  <text x="400" y="355" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#f59e0b">Audit Agent</text>
                  <path d="M400 300 L 400 260" stroke="#fcd34d" strokeWidth="2" strokeDasharray="5,5" />
                  <polygon points="403,256 397,256 400,264" fill="#fcd34d" />
                </g>
              </svg>
            </div>
          </div>
        </div>
      </Section>
      
      {/* Security Measures */}
      <Section>
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">Security Measures</h2>
          <p className="text-slate-600 text-center mb-12">
            IRISPay implements multiple layers of security to protect user data and ensure safe transactions.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                title: "Biometric Security",
                description: "Iris patterns are nearly impossible to fake, providing a higher level of security than fingerprints or facial recognition."
              },
              {
                title: "End-to-End Encryption",
                description: "All data transmitted between components is encrypted using AES-256 encryption, preventing data interception."
              },
              {
                title: "Secure Biometric Storage",
                description: "Biometric templates are stored as encrypted mathematical representations, not actual images."
              },
              {
                title: "Fraud Detection",
                description: "AI-powered systems continuously monitor for suspicious patterns and anomalies in real-time."
              },
              {
                title: "Liveness Detection",
                description: "Advanced techniques ensure the iris being scanned belongs to a living person, preventing the use of photos or prosthetics."
              },
              {
                title: "Secure Local Processing",
                description: "Sensitive operations are performed on-device, minimizing data transmission and potential exposure."
              }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
              >
                <Card hover>
                  <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                  <p className="text-slate-600">{item.description}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>
    </div>
  );
};

export default HowItWorksPage;