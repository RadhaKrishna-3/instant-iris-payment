import React, { useEffect, useState, useRef } from 'react';
import Section from '../components/common/Section';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import { motion } from 'framer-motion';
import { 
  Eye,
  ShieldCheck,
  CircleDollarSign,
  UserCircle,
  ArrowRight,
  RefreshCcw,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

const DemoPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Interactive Demo - IRISPay';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);
  
  const [demoStage, setDemoStage] = useState<number>(0);
  const [processing, setProcessing] = useState<boolean>(false);
  const [success, setSuccess] = useState<boolean | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [amount, setAmount] = useState<string>('75.00');
  const [merchant, setMerchant] = useState<string>('Coffee Shop');
  const [loadingText, setLoadingText] = useState<string>('');
  
  const stages = [
    { title: "Start Demo", description: "Experience IRISPay's secure payment process" },
    { title: "Payment Details", description: "Enter transaction information" },
    { title: "Iris Scan", description: "Look into the scanner for authentication" },
    { title: "Processing", description: "Our AI agents are verifying your identity and processing payment" },
    { title: "Confirmation", description: "Payment complete!" }
  ];
  
  useEffect(() => {
    if (demoStage === 3) {
      startIrisScan();
    }
    
    if (demoStage === 4) {
      startProcessingAnimation();
    }
  }, [demoStage]);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || demoStage !== 3) return;
    
    // Drawing logic for the iris scan visualization
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const maxRadius = Math.min(canvas.width, canvas.height) * 0.4;
    
    let currentRadius = 0;
    let scanAngle = 0;
    let scanning = false;
    
    const drawIris = () => {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Draw iris background
      ctx.beginPath();
      ctx.arc(centerX, centerY, maxRadius, 0, Math.PI * 2);
      ctx.fillStyle = '#4c1d95';
      ctx.fill();
      
      // Draw iris details
      const numLines = 48;
      for (let i = 0; i < numLines; i++) {
        const angle = (i * Math.PI * 2) / numLines;
        const innerRadius = maxRadius * 0.2;
        const outerRadius = maxRadius * 0.9;
        
        ctx.beginPath();
        ctx.moveTo(
          centerX + innerRadius * Math.cos(angle),
          centerY + innerRadius * Math.sin(angle)
        );
        ctx.lineTo(
          centerX + outerRadius * Math.cos(angle),
          centerY + outerRadius * Math.sin(angle)
        );
        ctx.strokeStyle = '#5b21b6';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      
      // Draw pupil
      ctx.beginPath();
      ctx.arc(centerX, centerY, maxRadius * 0.3, 0, Math.PI * 2);
      ctx.fillStyle = '#18181b';
      ctx.fill();
      
      // Draw highlight
      ctx.beginPath();
      ctx.arc(centerX - maxRadius * 0.15, centerY - maxRadius * 0.15, maxRadius * 0.08, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.fill();
      
      if (scanning) {
        // Draw scanning effect
        scanAngle += 0.1;
        
        // Horizontal scan line
        const scanY = centerY + Math.sin(scanAngle) * maxRadius * 0.6;
        
        ctx.beginPath();
        ctx.moveTo(centerX - maxRadius, scanY);
        ctx.lineTo(centerX + maxRadius, scanY);
        ctx.strokeStyle = 'rgba(20, 184, 166, 0.8)';
        ctx.lineWidth = 3;
        ctx.stroke();
        
        // Scanning circle that grows and shrinks
        currentRadius = maxRadius * 0.5 + Math.sin(scanAngle * 0.5) * maxRadius * 0.3;
        ctx.beginPath();
        ctx.arc(centerX, centerY, currentRadius, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(20, 184, 166, 0.4)';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      
      if (demoStage === 3) {
        requestAnimationFrame(drawIris);
      }
    };
    
    // Start animation after a short delay
    setTimeout(() => {
      scanning = true;
    }, 1000);
    
    const animate = requestAnimationFrame(drawIris);
    
    return () => {
      cancelAnimationFrame(animate);
      scanning = false;
    };
  }, [demoStage]);
  
  const startIrisScan = () => {
    setProcessing(true);
    
    // Simulate scanning process
    setTimeout(() => {
      setProcessing(false);
      setDemoStage(4);
    }, 5000);
  };
  
  const startProcessingAnimation = () => {
    setProcessing(true);
    
    const processingSteps = [
      "Initializing security protocols...",
      "Authenticating biometric data...",
      "Validating transaction details...",
      "Checking for suspicious patterns...",
      "Connecting to banking network...",
      "Processing payment...",
      "Generating receipt...",
      "Transaction complete!"
    ];
    
    let currentStep = 0;
    
    const animateProcessingText = () => {
      if (currentStep < processingSteps.length) {
        setLoadingText(processingSteps[currentStep]);
        currentStep++;
        setTimeout(animateProcessingText, 800);
      } else {
        setTimeout(() => {
          setProcessing(false);
          setSuccess(true);
          setDemoStage(5);
        }, 500);
      }
    };
    
    animateProcessingText();
  };
  
  const resetDemo = () => {
    setDemoStage(0);
    setProcessing(false);
    setSuccess(null);
    setAmount('75.00');
    setMerchant('Coffee Shop');
    setLoadingText('');
  };
  
  return (
    <div>
      {/* Hero section */}
      <Section className="bg-gradient-to-br from-purple-50 to-teal-50 pt-16 pb-20">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Try <span className="gradient-text">IRISPay</span> Demo
          </h1>
          <p className="text-slate-600 text-lg md:text-xl">
            Experience our revolutionary biometric payment system with this interactive demo.
          </p>
        </div>
      </Section>
      
      {/* Demo section */}
      <Section>
        <div className="max-w-4xl mx-auto">
          {/* Progress bar */}
          <div className="mb-12">
            <div className="flex justify-between mb-2">
              {stages.map((stage, index) => (
                index < stages.length - 1 && (
                  <div key={index} className="flex-1 text-center">
                    <div 
                      className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center text-sm ${
                        demoStage >= index + 1 
                          ? 'bg-purple-600 text-white' 
                          : 'bg-slate-200 text-slate-500'
                      }`}
                    >
                      {index + 1}
                    </div>
                    <div className={`text-sm mt-2 ${
                      demoStage >= index + 1 
                        ? 'text-purple-600 font-medium' 
                        : 'text-slate-500'
                    }`}>
                      {stage.title}
                    </div>
                  </div>
                )
              ))}
            </div>
            <div className="relative h-2 bg-slate-200 rounded-full">
              <div 
                className="absolute left-0 top-0 h-full bg-purple-600 rounded-full transition-all duration-500"
                style={{ width: `${(demoStage / (stages.length - 1)) * 100}%` }}
              ></div>
            </div>
          </div>
          
          {/* Demo content */}
          <Card className="p-8 md:p-12">
            {demoStage === 0 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center"
              >
                <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Eye className="w-10 h-10 text-purple-600" />
                </div>
                <h2 className="text-2xl font-bold mb-4">Welcome to the IRISPay Demo</h2>
                <p className="text-slate-600 mb-8 max-w-lg mx-auto">
                  This interactive demonstration will guide you through the IRISPay payment process,
                  from transaction details to iris authentication and payment confirmation.
                </p>
                <Button 
                  onClick={() => setDemoStage(1)} 
                  variant="primary" 
                  size="lg"
                  icon={<ArrowRight size={20} />}
                  iconPosition="right"
                >
                  Start Demo
                </Button>
              </motion.div>
            )}
            
            {demoStage === 1 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <h2 className="text-2xl font-bold mb-6">Enter Payment Details</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Merchant Name
                    </label>
                    <input
                      type="text"
                      value={merchant}
                      onChange={(e) => setMerchant(e.target.value)}
                      className="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">
                      Amount ($)
                    </label>
                    <input
                      type="text"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                  </div>
                </div>
                
                <div className="bg-slate-50 p-6 rounded-lg mb-8">
                  <h3 className="text-lg font-medium mb-4">Transaction Summary</h3>
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-600">Merchant:</span>
                    <span className="font-medium">{merchant}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-600">Amount:</span>
                    <span className="font-medium">${amount}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-slate-600">Date:</span>
                    <span className="font-medium">{new Date().toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Time:</span>
                    <span className="font-medium">{new Date().toLocaleTimeString()}</span>
                  </div>
                </div>
                
                <div className="flex justify-between">
                  <Button 
                    onClick={() => setDemoStage(0)} 
                    variant="outline"
                  >
                    Back
                  </Button>
                  <Button 
                    onClick={() => setDemoStage(2)} 
                    variant="primary"
                    icon={<ArrowRight size={20} />}
                    iconPosition="right"
                  >
                    Continue
                  </Button>
                </div>
              </motion.div>
            )}
            
            {demoStage === 2 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center"
              >
                <h2 className="text-2xl font-bold mb-6">Ready for Iris Authentication</h2>
                <p className="text-slate-600 mb-8 max-w-lg mx-auto">
                  Look directly at the camera to begin the iris scanning process.
                  Keep your eyes open and try not to blink during the scan.
                </p>
                
                <div className="w-64 h-64 mx-auto bg-slate-100 rounded-full mb-8 flex items-center justify-center">
                  <Eye className="w-20 h-20 text-slate-400" />
                </div>
                
                <div className="flex justify-between">
                  <Button 
                    onClick={() => setDemoStage(1)} 
                    variant="outline"
                  >
                    Back
                  </Button>
                  <Button 
                    onClick={() => setDemoStage(3)} 
                    variant="primary"
                    icon={<ArrowRight size={20} />}
                    iconPosition="right"
                  >
                    Start Scan
                  </Button>
                </div>
              </motion.div>
            )}
            
            {demoStage === 3 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center"
              >
                <h2 className="text-2xl font-bold mb-6">Scanning Iris</h2>
                <p className="text-slate-600 mb-8 max-w-lg mx-auto">
                  Please hold still while we scan your iris...
                </p>
                
                <div className="w-64 h-64 mx-auto bg-slate-100 rounded-full mb-8 overflow-hidden">
                  <canvas ref={canvasRef} className="w-full h-full" />
                </div>
                
                <div className="flex justify-center">
                  <div className="animate-pulse flex space-x-2 items-center">
                    <div className="w-3 h-3 bg-purple-600 rounded-full"></div>
                    <div className="w-3 h-3 bg-purple-600 rounded-full animation-delay-200"></div>
                    <div className="w-3 h-3 bg-purple-600 rounded-full animation-delay-400"></div>
                  </div>
                </div>
              </motion.div>
            )}
            
            {demoStage === 4 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center"
              >
                <h2 className="text-2xl font-bold mb-6">Processing Payment</h2>
                <p className="text-slate-600 mb-8 max-w-lg mx-auto">
                  Our multi-agent system is verifying your identity and processing your payment.
                </p>
                
                <div className="max-w-md mx-auto bg-slate-50 rounded-lg p-6 mb-8">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                      <UserCircle className="w-6 h-6 text-purple-600" />
                    </div>
                    <div className="text-left">
                      <div className="text-sm text-slate-500">User</div>
                      <div className="font-medium">John Doe</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-10 h-10 bg-teal-100 rounded-full flex items-center justify-center">
                      <CircleDollarSign className="w-6 h-6 text-teal-600" />
                    </div>
                    <div className="text-left">
                      <div className="text-sm text-slate-500">Amount</div>
                      <div className="font-medium">${amount}</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center">
                      <ShieldCheck className="w-6 h-6 text-amber-600" />
                    </div>
                    <div className="text-left">
                      <div className="text-sm text-slate-500">Status</div>
                      <div className="font-medium">{loadingText}</div>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-center">
                  <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-purple-700"></div>
                </div>
              </motion.div>
            )}
            
            {demoStage === 5 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center"
              >
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-10 h-10 text-green-600" />
                </div>
                <h2 className="text-2xl font-bold mb-4">Payment Successful!</h2>
                <p className="text-slate-600 mb-8 max-w-lg mx-auto">
                  Your payment to {merchant} for ${amount} has been processed successfully.
                </p>
                
                <div className="max-w-md mx-auto bg-green-50 border border-green-100 rounded-lg p-6 mb-8">
                  <div className="text-left">
                    <div className="flex justify-between mb-4 pb-4 border-b border-green-100">
                      <div className="text-slate-600">Transaction ID:</div>
                      <div className="font-medium">IRISPay-{Math.floor(Math.random() * 1000000)}</div>
                    </div>
                    
                    <div className="flex justify-between mb-2">
                      <div className="text-slate-600">Date:</div>
                      <div>{new Date().toLocaleDateString()}</div>
                    </div>
                    
                    <div className="flex justify-between mb-2">
                      <div className="text-slate-600">Time:</div>
                      <div>{new Date().toLocaleTimeString()}</div>
                    </div>
                    
                    <div className="flex justify-between mb-2">
                      <div className="text-slate-600">Merchant:</div>
                      <div>{merchant}</div>
                    </div>
                    
                    <div className="flex justify-between mb-2">
                      <div className="text-slate-600">Amount:</div>
                      <div className="font-medium">${amount}</div>
                    </div>
                    
                    <div className="flex justify-between mb-2">
                      <div className="text-slate-600">Status:</div>
                      <div className="text-green-600 font-medium">Completed</div>
                    </div>
                    
                    <div className="flex justify-between">
                      <div className="text-slate-600">Authentication:</div>
                      <div className="text-purple-600 font-medium">Iris Biometric</div>
                    </div>
                  </div>
                </div>
                
                <Button 
                  onClick={resetDemo} 
                  variant="primary"
                  icon={<RefreshCcw size={20} />}
                  iconPosition="left"
                >
                  Restart Demo
                </Button>
              </motion.div>
            )}
          </Card>
        </div>
      </Section>
    </div>
  );
};

export default DemoPage;