import React, { useEffect } from 'react';
import Section from '../components/common/Section';
import Card from '../components/common/Card';
import { motion } from 'framer-motion';
import { 
  Eye, 
  BrainCircuit, 
  Server, 
  Database, 
  Shield, 
  Layers 
} from 'lucide-react';

const TechnologyPage: React.FC = () => {
  useEffect(() => {
    document.title = 'Technology - IRISPay';
    
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);
  
  return (
    <div>
      {/* Hero section */}
      <Section className="bg-gradient-to-br from-purple-50 to-teal-50 pt-16 pb-20">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Our <span className="gradient-text">Technology</span>
          </h1>
          <p className="text-slate-600 text-lg md:text-xl">
            The cutting-edge technologies behind IRISPay's secure, 
            instant biometric payment system.
          </p>
        </div>
      </Section>
      
      {/* Technology Overview */}
      <Section>
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">Technology Stack</h2>
          <p className="text-slate-600 text-center mb-12">
            IRISPay combines multiple advanced technologies to create a seamless, 
            secure payment experience powered by artificial intelligence.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Eye size={32} />,
                title: "Iris Recognition",
                description: "Advanced computer vision algorithms identify and authenticate users based on their unique iris patterns.",
                items: [
                  "OpenCV & Dlib for eye detection",
                  "Deep Learning (CNN models) for pattern recognition",
                  "Real-time image processing"
                ],
                color: "bg-purple-100 text-purple-700"
              },
              {
                icon: <BrainCircuit size={32} />,
                title: "On-Prem LLMs",
                description: "Local language models provide secure, intelligent processing without exposing sensitive data.",
                items: [
                  "Ollama for secure on-device processing",
                  "Custom fine-tuned models for payment contexts",
                  "Optimized for low-latency decision making"
                ],
                color: "bg-teal-100 text-teal-700"
              },
              {
                icon: <Layers size={32} />,
                title: "Multi-Agent Framework",
                description: "Specialized AI agents working together to handle different aspects of the payment process.",
                items: [
                  "Modular agent architecture",
                  "Secure inter-agent communication protocols",
                  "Parallel processing for speed optimization"
                ],
                color: "bg-blue-100 text-blue-700"
              },
              {
                icon: <Database size={32} />,
                title: "Secure Databases",
                description: "Lightweight, local storage solutions that maintain data integrity and security.",
                items: [
                  "SQLite for local biometric data storage",
                  "Fast read/write for embedded systems",
                  "Encrypted data storage"
                ],
                color: "bg-amber-100 text-amber-700"
              },
              {
                icon: <Server size={32} />,
                title: "API Integration",
                description: "Secure connections to banking and payment systems using standardized protocols.",
                items: [
                  "UPI / Payment Gateway API integrations",
                  "Bank integration layers",
                  "Secure OAuth authentication"
                ],
                color: "bg-indigo-100 text-indigo-700"
              },
              {
                icon: <Shield size={32} />,
                title: "Security Stack",
                description: "Multi-layered security approach to protect sensitive user data and financial information.",
                items: [
                  "AES Encryption for all data",
                  "JWT / OAuth for secure communications",
                  "Real-time fraud detection systems"
                ],
                color: "bg-red-100 text-red-700"
              }
            ].map((tech, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
              >
                <Card hover className="h-full">
                  <div className="flex flex-col h-full">
                    <div className={`w-16 h-16 rounded-lg flex items-center justify-center mb-5 ${tech.color}`}>
                      {tech.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{tech.title}</h3>
                    <p className="text-slate-600 mb-4">{tech.description}</p>
                    <ul className="text-sm text-slate-600 space-y-2 mt-auto">
                      {tech.items.map((item, i) => (
                        <li key={i} className="flex items-start">
                          <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </Section>
      
      {/* System Architecture */}
      <Section backgroundColor="bg-slate-50">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold mb-12 text-center">System Architecture</h2>
          
          <div className="bg-white rounded-xl shadow-md p-8 overflow-hidden mb-12">
            <div className="relative">
              <svg className="w-full h-auto" viewBox="0 0 800 500" xmlns="http://www.w3.org/2000/svg">
                {/* User Layer */}
                <rect x="50" y="50" width="700" height="80" rx="8" fill="#f5f3ff" stroke="#8b5cf6" strokeWidth="2" />
                <text x="400" y="90" textAnchor="middle" fontSize="18" fontWeight="bold" fill="#8b5cf6">User Interface Layer</text>
                <rect x="100" y="70" width="150" height="40" rx="4" fill="#ede9fe" stroke="#8b5cf6" strokeWidth="1" />
                <text x="175" y="95" textAnchor="middle" fontSize="14" fill="#8b5cf6">Iris Scanner</text>
                <rect x="325" y="70" width="150" height="40" rx="4" fill="#ede9fe" stroke="#8b5cf6" strokeWidth="1" />
                <text x="400" y="95" textAnchor="middle" fontSize="14" fill="#8b5cf6">Payment Terminal</text>
                <rect x="550" y="70" width="150" height="40" rx="4" fill="#ede9fe" stroke="#8b5cf6" strokeWidth="1" />
                <text x="625" y="95" textAnchor="middle" fontSize="14" fill="#8b5cf6">Mobile App</text>
                
                {/* Agent Layer */}
                <rect x="50" y="160" width="700" height="120" rx="8" fill="#ecfdf5" stroke="#10b981" strokeWidth="2" />
                <text x="400" y="185" textAnchor="middle" fontSize="18" fontWeight="bold" fill="#10b981">Multi-Agent Layer</text>
                <rect x="80" y="205" width="120" height="50" rx="4" fill="#d1fae5" stroke="#10b981" strokeWidth="1" />
                <text x="140" y="235" textAnchor="middle" fontSize="12" fill="#10b981">User ID Agent</text>
                <rect x="220" y="205" width="120" height="50" rx="4" fill="#d1fae5" stroke="#10b981" strokeWidth="1" />
                <text x="280" y="235" textAnchor="middle" fontSize="12" fill="#10b981">Transaction Agent</text>
                <rect x="360" y="205" width="120" height="50" rx="4" fill="#d1fae5" stroke="#10b981" strokeWidth="1" />
                <text x="420" y="235" textAnchor="middle" fontSize="12" fill="#10b981">Security Agent</text>
                <rect x="500" y="205" width="120" height="50" rx="4" fill="#d1fae5" stroke="#10b981" strokeWidth="1" />
                <text x="560" y="235" textAnchor="middle" fontSize="12" fill="#10b981">Bank API Agent</text>
                <rect x="640" y="205" width="80" height="50" rx="4" fill="#d1fae5" stroke="#10b981" strokeWidth="1" />
                <text x="680" y="235" textAnchor="middle" fontSize="12" fill="#10b981">Audit Agent</text>
                
                {/* Core Layer */}
                <rect x="50" y="310" width="700" height="80" rx="8" fill="#eff6ff" stroke="#3b82f6" strokeWidth="2" />
                <text x="400" y="350" textAnchor="middle" fontSize="18" fontWeight="bold" fill="#3b82f6">Core Services Layer</text>
                <rect x="100" y="330" width="150" height="40" rx="4" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1" />
                <text x="175" y="355" textAnchor="middle" fontSize="14" fill="#3b82f6">On-Prem LLMs</text>
                <rect x="325" y="330" width="150" height="40" rx="4" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1" />
                <text x="400" y="355" textAnchor="middle" fontSize="14" fill="#3b82f6">Authentication</text>
                <rect x="550" y="330" width="150" height="40" rx="4" fill="#dbeafe" stroke="#3b82f6" strokeWidth="1" />
                <text x="625" y="355" textAnchor="middle" fontSize="14" fill="#3b82f6">Security Services</text>
                
                {/* Data Layer */}
                <rect x="50" y="420" width="700" height="60" rx="8" fill="#fef3c7" stroke="#d97706" strokeWidth="2" />
                <text x="400" y="455" textAnchor="middle" fontSize="18" fontWeight="bold" fill="#d97706">Data Storage Layer</text>
                <rect x="150" y="435" width="150" height="30" rx="4" fill="#fef3c7" stroke="#d97706" strokeWidth="1" />
                <text x="225" y="455" textAnchor="middle" fontSize="14" fill="#d97706">SQLite Database</text>
                <rect x="500" y="435" width="150" height="30" rx="4" fill="#fef3c7" stroke="#d97706" strokeWidth="1" />
                <text x="575" y="455" textAnchor="middle" fontSize="14" fill="#d97706">Encrypted Storage</text>
                
                {/* Connection Lines */}
                <line x1="400" y1="130" x2="400" y2="160" stroke="#8b5cf6" strokeWidth="2" strokeDasharray="5,5" />
                <line x1="400" y1="280" x2="400" y2="310" stroke="#10b981" strokeWidth="2" strokeDasharray="5,5" />
                <line x1="400" y1="390" x2="400" y2="420" stroke="#3b82f6" strokeWidth="2" strokeDasharray="5,5" />
              </svg>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <Card>
                <h3 className="text-xl font-semibold mb-4">Technical Requirements</h3>
                <ul className="space-y-3 text-slate-600">
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Camera:</strong> High-resolution camera capable of capturing detailed iris patterns</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Processing:</strong> Low-latency CPU/GPU for real-time biometric processing</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Memory:</strong> 4GB+ RAM for running the multi-agent system</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Storage:</strong> 16GB+ for the application, models, and local database</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Connectivity:</strong> Secure internet connection for bank API communications</span>
                  </li>
                </ul>
              </Card>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <Card>
                <h3 className="text-xl font-semibold mb-4">Development Approach</h3>
                <ul className="space-y-3 text-slate-600">
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Modular Architecture:</strong> Each component is developed and tested independently</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Security-First:</strong> All code undergoes rigorous security testing</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Privacy by Design:</strong> System designed to minimize data collection and exposure</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Continuous Testing:</strong> Automated testing for biometric accuracy and security</span>
                  </li>
                  <li className="flex items-start">
                    <span className="inline-block w-2 h-2 bg-purple-500 rounded-full mt-1.5 mr-2 flex-shrink-0"></span>
                    <span><strong>Performance Optimization:</strong> Continuous benchmarking for transaction speed</span>
                  </li>
                </ul>
              </Card>
            </motion.div>
          </div>
        </div>
      </Section>
    </div>
  );
};

export default TechnologyPage;